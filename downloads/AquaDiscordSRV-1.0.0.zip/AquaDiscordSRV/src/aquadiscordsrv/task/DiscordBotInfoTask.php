<?php

declare(strict_types=1);

namespace aquadiscordsrv\task;

use aquadiscordsrv\Main;
use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use pocketmine\utils\Internet;
use pocketmine\utils\InternetException;

class DiscordBotInfoTask extends AsyncTask{

	/** @var string */
	private $botToken;

	/** @var string|null */
	private $botUserId = null;

	public function __construct(string $botToken){
		$this->botToken = $botToken;
	}

	public function onRun() : void{
		try{
			[$body, , $httpCode] = Internet::simpleCurl(
				"https://discord.com/api/v10/users/@me",
				10,
				["Authorization: Bot " . $this->botToken]
			);

			if($httpCode === 200){
				$data = json_decode($body, true);
				if(is_array($data) && isset($data["id"])){
					$this->botUserId = (string) $data["id"];
				}
			}
		}catch(InternetException $e){
			//swallow - this only affects echo-loop filtering, it isn't fatal to the bridge working
		}

		$this->setResult($this->botUserId);
	}

	public function onCompletion(Server $server) : void{
		$plugin = Main::getInstance();
		if($plugin === null || !$plugin->isEnabled()){
			return;
		}

		$id = $this->getResult();
		if(is_string($id) && $id !== ""){
			$plugin->setBotUserId($id);
			$plugin->getLogger()->info("Connected to Discord as bot user " . $id);
		}else{
			$plugin->getLogger()->warning("Could not verify the bot token against the Discord API - check BotToken in config.yml");
		}
	}
}
