<?php

declare(strict_types=1);

namespace aquadiscordsrv\task;

use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use pocketmine\utils\Internet;
use pocketmine\utils\InternetException;
use function json_encode;

class DiscordSendTask extends AsyncTask{

	/** @var string */
	private $botToken;
	/** @var string */
	private $channelId;
	/** @var string */
	private $webhookUrl;
	/** @var string */
	private $content;
	/** @var string|null */
	private $username;
	/** @var string|null */
	private $avatarUrl;

	public function __construct(string $botToken, string $channelId, string $webhookUrl, string $content, ?string $username = null, ?string $avatarUrl = null){
		$this->botToken = $botToken;
		$this->channelId = $channelId;
		$this->webhookUrl = $webhookUrl;
		$this->content = $content;
		$this->username = $username;
		$this->avatarUrl = $avatarUrl;
	}

	public function onRun() : void{
		try{
			if($this->webhookUrl !== "" && $this->username !== null){
				//Send "as the player" through the webhook, DiscordSRV-style
				$payload = ["content" => $this->content, "username" => $this->username];
				if($this->avatarUrl !== null){
					$payload["avatar_url"] = $this->avatarUrl;
				}

				Internet::simpleCurl(
					$this->webhookUrl . "?wait=false",
					10,
					["Content-Type: application/json"],
					[
						CURLOPT_POST => 1,
						CURLOPT_POSTFIELDS => json_encode($payload)
					]
				);
			}else{
				//Send as the bot directly to the channel
				Internet::simpleCurl(
					"https://discord.com/api/v10/channels/" . $this->channelId . "/messages",
					10,
					[
						"Authorization: Bot " . $this->botToken,
						"Content-Type: application/json"
					],
					[
						CURLOPT_POST => 1,
						CURLOPT_POSTFIELDS => json_encode(["content" => $this->content])
					]
				);
			}
		}catch(InternetException $e){
			//best-effort delivery; a dropped chat/status line to Discord should never crash the server
		}
	}

	public function onCompletion(Server $server) : void{
		//nothing to do on the main thread for a fire-and-forget send
	}
}
