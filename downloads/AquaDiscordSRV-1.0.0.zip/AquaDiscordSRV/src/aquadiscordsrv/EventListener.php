<?php

declare(strict_types=1);

namespace aquadiscordsrv;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\utils\TextFormat;

class EventListener implements Listener{

	/** @var Main */
	private $plugin;

	public function __construct(Main $plugin){
		$this->plugin = $plugin;
	}

	private function placeholders(array $extra = []) : array{
		$server = $this->plugin->getServer();
		return $extra + [
			"{online}" => (string) count($server->getOnlinePlayers()),
			"{max}" => (string) $server->getMaxPlayers()
		];
	}

	/**
	 * @ignoreCancelled true
	 */
	public function onChat(PlayerChatEvent $event) : void{
		$player = $event->getPlayer();
		$format = $this->plugin->getFormat("Chat", "**{player}**: {message}");
		$placeholders = $this->placeholders([
			"{player}" => $player->getName(),
			"{message}" => TextFormat::clean($event->getMessage())
		]);

		$this->plugin->sendDiscordChatMessage(
			strtr($format, $placeholders),
			$player->getName(),
			$this->plugin->getSkinAvatarUrl($player->getName())
		);
	}

	/**
	 * @ignoreCancelled true
	 */
	public function onJoin(PlayerJoinEvent $event) : void{
		$player = $event->getPlayer();
		$format = $this->plugin->getFormat("Join", ":green_circle: **{player}** joined the game.");
		$placeholders = $this->placeholders(["{player}" => $player->getName()]);

		$this->plugin->sendDiscordStatusMessage(strtr($format, $placeholders));
	}

	public function onQuit(PlayerQuitEvent $event) : void{
		$player = $event->getPlayer();
		$format = $this->plugin->getFormat("Leave", ":red_circle: **{player}** left the game.");
		$placeholders = $this->placeholders(["{player}" => $player->getName()]);

		$this->plugin->sendDiscordStatusMessage(strtr($format, $placeholders));
	}

	public function onDeath(PlayerDeathEvent $event) : void{
		$deathMessage = (string) $event->getDeathMessage();
		if($deathMessage === ""){
			return;
		}

		$format = $this->plugin->getFormat("Death", ":skull: {deathmessage}");
		$placeholders = $this->placeholders(["{deathmessage}" => TextFormat::clean($deathMessage)]);

		$this->plugin->sendDiscordStatusMessage(strtr($format, $placeholders));
	}
}
