# AquaDiscordSRV

A DiscordSRV-style Discord ⇄ Minecraft bridge, built for Aquamarine's plugin API
(Genisys-derived, API 3.0.1).

## What's actually in here vs. real DiscordSRV

DiscordSRV is built on JDA, a full Discord Gateway (WebSocket) client with a live
member/role/channel cache. Aquamarine's plugin API doesn't give plugins a persistent
socket or an event loop to run one on - `AsyncTask`s are meant to run for a few
seconds and then die. So this plugin is a genuine, working bridge, but it's built
around REST polling instead of a Gateway connection, and a few DiscordSRV features
that fundamentally need that live connection (or a linked-accounts database) are
left out rather than faked:

**Included:**
- In-game chat → Discord (as the bot, or "as the player" via an optional webhook,
  using the player's Minecraft skin as the avatar)
- Discord chat channel → in-game chat (polled every `PollIntervalSeconds`)
- Join / leave / death messages → Discord
- Server start/stop notices → Discord
- Optional: tails `server.log` and mirrors new lines to a console channel
- Optional (off by default): executes messages typed in a console channel as
  server console commands
- `/discordsrv reload` and `/discordsrv status`

**Not included, and why:**
- Role sync, ban sync, nickname sync, voice proximity chat - all of DiscordSRV's
  guild-state features need a live member/role cache from the Gateway, which
  isn't available here.
- `/discord link` account linking - no blocker in principle, just genuinely more
  infrastructure (a persistent link database + verification flow) than fits in
  a first pass. Say the word if you want this added next.
- Live console streaming is a log-file tail on an interval, not truly instant,
  since attaching to Aquamarine's threaded logger from a plugin risks a pthreads
  crash rather than a clean error.

## Setup

Same flow as DiscordSRV's own docs:

1. Create an application + bot at https://discord.com/developers/applications
2. On the Bot tab, enable **Server Members Intent** and **Message Content Intent**
3. Reset the token, copy it into `config.yml` as `BotToken`
4. Invite the bot to your guild (OAuth2 URL Generator: `bot` scope, plus
   View Channel / Send Messages / Read Message History / Embed Links)
5. Enable Developer Mode in Discord, right-click your chat channel → Copy Channel ID,
   paste it into `config.yml` as `Channels.Chat`
6. Set `Enabled: true`
7. Drop this folder into your server's `plugins/` directory and restart
   (or run `/discordsrv reload` if the folder was already there)

See the comments in `config.yml` for every option, including the optional webhook
and console-relay settings.
